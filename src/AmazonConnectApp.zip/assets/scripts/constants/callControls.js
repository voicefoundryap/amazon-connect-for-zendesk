export const buttons = {
    SUSPEND: 'suspendCallRecording',
    RESUME: 'resumeCallRecording',
}

export const resizeId = 'withCallControls';
export const containerId = 'callControls';